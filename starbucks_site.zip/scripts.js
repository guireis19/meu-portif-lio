const circulo = document.querySelector('.circulo');
const copo = document.querySelector('.copo');

function trocarACor(cor) {
    if (circulo) {
        circulo.style.background = cor;
    }
}

function trocarImagem(endereco) {
    if (copo) {
        copo.src = endereco;
    }
}
